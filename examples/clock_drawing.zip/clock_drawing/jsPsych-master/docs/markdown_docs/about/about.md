# About jsPsych

jsPsych was created by [Josh de Leeuw](http://pages.iu.edu/~jodeleeu). Other contributors to the library are listed in the [contributors document](https://github.com/jodeleeuw/jsPsych/blob/master/contributors.md) in the jsPsych repository.

### Citation

de Leeuw, J. R. (2015). jsPsych: A JavaScript library for creating behavioral experiments in a web browser. _Behavior Research Methods_, _47_(1), 1-12. doi:10.3758/s13428-014-0458-y.

---

Documentation generated with [mkdocs](http://www.mkdocs.org)
